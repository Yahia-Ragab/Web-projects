$(document).ready(function check_id(btn){
    $(btn).click(function(e){
        e.preventDefault();
        var id=$(".n_id").val();
        var password=$(".pass").val();
        if(id ==='' || password===''){
            $(".error_handel").text("*Error: Inputs must be filled");
        }
        let new_id = String(id).split("").map((id) => {
            return Number(id)
            })
        if(new_id.length<14){
            $(".error_handel").text("*Error: National ID suppose to be a 14-digit number");
        }
    });
});