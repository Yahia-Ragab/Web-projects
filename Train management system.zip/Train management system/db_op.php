<?php
    include("conn.php");
    class  Db_op{
        function insert1($db_name,$input1){
            global $conn;
            $sql = "INSERT INTO $db_name VALUES ($input1)";
            return mysqli_query($conn, $sql)? true:false;
        }
        function insert2($db_name, $input1, $input2, $c1, $c2){
            global $conn;
            $input1 = mysqli_real_escape_string($conn, $input1);
            $input2 = mysqli_real_escape_string($conn, $input2);
            $sql = "INSERT INTO $db_name ($c1, $c2) VALUES ('$input1', '$input2')";
            return mysqli_query($conn, $sql) ? true : false;
        }
        
        function insert3($db_name,$input1, $input2, $input3,$c1,$c2,$c3){
            global $conn;
            $sql = "INSERT INTO $db_name ($c1,$c2,$c3) VALUES ('$input1','$input2','$input3')";
            return mysqli_query($conn, $sql)? true:false;
        }
        function insert4($db_name,$input1, $input2, $input3, $input4,$c1,$c2, $c3, $c4){
            global $conn;
            $sql = "INSERT INTO $db_name ($c1,$c2, $c3, $c4) VALUES ($input1,$input2,$input3,$input4)";
            return mysqli_query($conn, $sql)? true:false;
        }
        function insert5($db_name,$input1, $input2, $input3, $input4,$input5,$c1,$c2, $c3, $c4,$c5){
            global $conn;
            $sql = "INSERT INTO $db_name ($c1,$c2, $c3, $c4,$c5) VALUES ('$input1','$input2','$input3','$input4','$input5')";
            return mysqli_query($conn, $sql)? true:false;
        }
        function insert6($db, $input1, $input2, $input3, $input4, $input5, $input6, $c1, $c2, $c3, $c4, $co5, $co6) {
            global $conn;
            $sql = "SELECT * FROM $db WHERE $c1 = '$input1'";
            $result = mysqli_query($conn, $sql);
            if ($result && mysqli_num_rows($result) == 0) { 
                $sql = "INSERT INTO $db ($c1, $c2, $c3, $c4, $co5, $co6) VALUES ('$input1', '$input2', '$input3', '$input4', '$input5', '$input6')";
                return mysqli_query($conn, $sql) ? true : false;
            } else {
                return false;
            }
        }
        
        function insert7($db,$input1,$input2,$input3,$input4,$input5,$input6,$input7,$co1,$co2,$co3,$co4,$co5,$co6,$co7){
            global $conn;
            $sql = "INSERT INTO $db ($co1,$co2,$co3,$co4,$co5,$co6,$co7)values
            ('$input1','$input2','$input3','$input4','$input5','$input6','$input7')";
            return mysqli_query($conn, $sql)? true:false;
        }
        function select($db){
            global $conn;
            $sql = "SELECT * FROM $db";
            $result = mysqli_query($conn, $sql);
            $rows = array();
            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    $rows[] = $row;
                }
                return $rows;
            } else {
                return false;
            }
        }
        function select1($db,$input,$column){
            global $conn;
            $sql = "SELECT * FROM $db WHERE $column=$input";
            $resualt=mysqli_query($conn,$sql);
            if($resualt->num_rows>0){
                $row=mysqli_fetch_array($resualt);
                return $row;
            }
            else{
                return false;
            }
        }
        function select2($db,$input1,$input2,$column1,$column2){
            global $conn;
            $sql = "SELECT * FROM $db WHERE $column1=$input1 and $column2=$input2";
            $resualt=mysqli_query($conn,$sql);
            if($resualt->num_rows>0){
                $row=mysqli_fetch_array($resualt);
                return $row;
            }
            else{
                return false;
            }
        }
        function select_all1($db, $input1,$column1){
            global $conn;
            $sql = "SELECT * FROM $db WHERE $column1='$input1' ";
            $result = mysqli_query($conn, $sql);
            $rows = array();
            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    $rows[] = $row;
                }
                return $rows;
            } else {
                return false;
            }
        }
        function select_all2($db, $input1, $input2, $column1, $column2){
            global $conn;
            $sql = "SELECT * FROM $db WHERE $column1='$input1' AND $column2='$input2'";
            $result = mysqli_query($conn, $sql);
            $rows = array();
            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    $rows[] = $row;
                }
                return $rows;
            } else {
                return false;
            }
        }
        function update($table, $value, $column, $condition, $value2) {
            global $conn;
            $update = "UPDATE $table SET $column='$value' WHERE $condition='$value2'";
            return mysqli_query($conn, $update) ? true : false;
        }
        function delete($db,$value,$column){
            global $conn;
            $sql = "DELETE from $db where $column=$value";
            return mysqli_query($conn, $sql)? true:false;
        }
    }
?>