<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="stylesheet.css">
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#login_btn").click(function(e){
                var id = $(".n_id").val();
                var password = $(".pass").val();
                if(id === '' || password === ''){
                    $(".error_handel").text("*Error: Inputs must be filled");
                }
                else {
                    let new_id = String(id).split("").map((id) => {
                        return Number(id);
                    });
                    if(new_id.length !== 14){
                        $(".error_handel").text("*Error: National ID should be a 14-digit number");
                    }
                    else {
                        $(".error_handel").text("");
                    }
                }
            });
        });
    </script>
    <style>
        body{
            background-image: url("img/OIG4.q_ouojLCRhAmnw.jpg");
        }    
    </style>
</head>
<body>
    <div class="form">
        <form action="" method="post">
            <div class="login_form">
                <h2 class="login_txt">Login</h2>
                <div class="btn_form">
                    <span class="error_handel" style="color: rgb(239, 255, 63);"></span>
                    <input type="number" name="login_n_id" class="n_id" id="input_field" placeholder="National ID">
                    <input type="password" name="login_pass" class="pass" id="input_field" placeholder="Password">
                    <button id="login_btn" name="login_btn">Login</button>
                    <a href="regiseter.php" style="font-size: large; color:rgb(239, 255, 63) ;">Don't have an account</a>
                </div>
            </div>
        </form>
    </div>
    
    <?php
    include("person.php");
    $p = new Person();
    if(isset($_POST["login_btn"])){
        $id = $_POST['login_n_id'];
        $pass = $_POST['login_pass'];
        $valid = $p->login($id,$pass);
        if($valid=='error'){
            echo "<script>$('.error_handel').text('*Error: Wrong National id or email');</script>";
        }
    }
    ?>

</body>
</html>
