<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track train</title>
    <script src="navigate.js"></script>
    <style>
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
        }
        .form{
            text-align: center;
            margin: 0 auto;
            border: 2px solid black;
            width: 500px;
            padding: 15px;
        }
        #input_field{
            margin-bottom: 10px;
            width: 300px;
            height: 20px;
            border-radius: 5px;
            font-family: cursive;
        }
        #book_btn{
            width: 70px;
            background: white;
            border-radius: 5px;
            color: green;
            font-family: cursive;
        }
        #book_btn:active{
            background-color: green;
            color: white;
        }
    </style>
</head>
<body>
    <div id="content"></div>
    <form action="" method="GET">
        <div class="form">
            <input type="number" name="j_id" id="input_field" placeholder="Enter journey ID"><br>
            <button id="book_btn" name="submit">Submit</button>
        </div>
    </form>
</body>
</html>
<?php
    include("person.php");
    $p=new Person();
    if(isset($_GET["submit"])){
        $id=$_GET['j_id'];
        $info=$p->track_train($id);
        echo '<h2 style="font-family:cursive;">Journey ID: '.$info[0]. '<br>Curreny station: '.$info[1].'</h2>';
    }
?>
