<?php
    include("admin.php");
    class Admin_st extends Admin{
        function display_st_state(){
            $db = new Db_op();
            $data=$_SESSION['data'];
            $station=$data[0][11].$data[0][12].$data[0][13];
            $train = $db->select_all1('active_trip',$station,'current_st');
            return $train;
        }
        function update_st_state($j_id){
            $db=new Db_op();
            $data=$_SESSION['data'];
            $station=$data[0][11].$data[0][12].$data[0][13];
            $end_st=$db->select1('journey',$j_id,'id');
            $db->insert2('st_data',$station,$j_id,'st_id','j_id');
            $end_st=$end_st[3];
            if($end_st==$station){
                $db->delete('active_trip',$j_id,'j_id');
                return true;
            }
            else{
                $db->update('active_trip',$station+1,'current_st','j_id',$j_id);
                return true;
            }
        }
        function add_delay($j_id,$delay){
            $db=new Db_op();
            $update=$db->update('active_trip',$delay,'delay','j_id',$j_id);
            return $update;
        }
        function see_report(){
            $db=new Db_op();
            $data=$_SESSION['data'];
            $station=$data[0][11].$data[0][12].$data[0][13];
            return $db->select_all1('st_data',$station,'st_id');
        }
        function start_j($j_id){
            $db=new Db_op();
            $data=$_SESSION['data'];
            $id=$data[0][11].$data[0][12].$data[0][13];
            $db->insert2('active_trip',$id,$j_id,'current_st','j_id');
        }
}
?>