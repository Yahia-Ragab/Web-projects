<?php
    include("conn.php");
    include("db_op.php");
    session_start();
    class Person{
        function login($id, $password){        
            $db = new Db_op();
            $result = $db->select2('person', $id, $password, 'n_id', 'password');
            if($result == false) {
                return "error";
            }
            if($result[6] == 1) {
                setcookie("login_cookie", $result[0] * 54 * 12 + 59, time() + 3600, '/');
                $_SESSION['data'] = $result;
                header("Location: user_home.php");
            } else if($result[6] == 2) {
                setcookie("login_cookie", $result[0] * 54 * 12 + 59, time() + 3600, '/');
                $_SESSION['data'] = $result;
                header("Location: admin_home.php");
            } else if($result[6] == 3) {
                setcookie("login_cookie", $result[0] * 54 * 12 + 59, time() + 3600, '/');
                $_SESSION['data'] = $result;
                header("Location: st_admin_home.php");
            }
        }
        
        function track_train($j_id) {
            $db = new Db_op();
            $active= $db->select1("active_trip", $j_id, "j_id");
            $st_name=$db->select1("station", $active[0], "id");
            $info=[$active[1],$st_name[1]];
            return $info;
        }
        function get_trip_info($id){
            $db=new Db_op();
            $resualt=$db->select1("journey", $id, "id");
            $st1=$db->select1("station", $resualt[2], "id");
            $st2=$db->select1("station", $resualt[3], "id");
            $info=[$resualt[0],$resualt[1],$st1[1],$st2[1],$resualt[4]];
            return $info;
        }
        function get_news(){
            $db=new Db_op();
            $resualt=$db->select('news');
            return $resualt;
        }
    }    
?>