<?php
    include("admin.php");
    $db=new Db_op();
    $train=$db->select('train');
    $station=$db->select('station');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add journey</title>
    <script src="navigat.js"></script>
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <style>
        body{
            margin: 0;
        }
        .form{
            display: flex;
            justify-content: center;
            text-align: center;
            margin: 0 auto;
        }
        .book_form{
            display: inline;
            border: 3px solid black;
            border-radius: 5px;
            text-align: center;
            width: 1000px;
            height: 120%;
            margin: 10px;
            padding: 10px;
        }
        #input_field{
            margin-bottom: 10px;
            width: 300px;
            height: 20px;
            border-radius: 5px;
            font-family: cursive;
        }
        #book_btn{
            width: 70px;
            background: white;
            border-radius: 5px;
            color: green;
            font-family: cursive;
        }
        #book_btn:active{
            background-color: green;
            color: white;
        }
        h2{
            font-family: cursive;
        }
    </style>
    </script>
</head>
<body>
    <div id="content"></div>
            <div class="form">
                <div class="book_form">
                    <form action="" method="post">
                        <h2 >Add journey</h2><br>
                        <select name="train" id="input_field">
                            <optgroup label="Train"></optgroup>
                            <?php
                                for($i=0;$i<count($train);$i++){
                                echo '<option value="'.$train[$i][0].'">'.$train[$i][0].'</option>';}
                            ?>
                        </select>
                        <select name="st1" id="input_field">
                            <optgroup label="Source staiotn"></optgroup>
                                <?php
                                   for($j=0;$j<count($station);$j++){ 
                                    echo '<option value="'.$station[$j][0].'">'.$station[$j][1].'</option>';}
                                ?>
                        </select>
                        <select name="st2" id="input_field">
                            <optgroup label="Destination staiotn"></optgroup>
                                <?php
                                   for($j=0;$j<count($station);$j++){ 
                                    echo '<option value="'.$station[$j][0].'">'.$station[$j][1].'</option>';}
                                ?>
                        </select><br>
                        Date<input type="date" id="input_field" name="date">
                        Time<input type="time" id="input_field" name="time" ><br>
                        return date<input type="date" id="input_field" name="r_date" ><br>
                        <button name="journey_btn" id="book_btn">Add</button><br>
                        <span id="error1" style="color: red;">.</span>
                    </form>
                </div>
            </div>
            <div class="form">
                <div class="book_form">
                    <form action="" method="post">
                        <h2 >Delete journey</h2><br>
                        <input type="number" name="journey_del" id="input_field" placeholder="Journey id">
                        <button id="book_btn" name="journey_btn_del">Delete</button><br>
                        <span id="error3" style="color: red;">.</span>
                    </form>
                </div>
            </div>
            <div class="form">
                <div class="book_form">
                    <form action="" method="post">
                        <h2 >Add train</h2><br>
                        <input type="number" name="train_id" id="input_field" placeholder="Train id">
                        <input type="number" placeholder="train's class A capacity" id="input_field" name="cap_a">
                        <input type="number" placeholder="train's class A capacity" id="input_field" name="cap_b"><br>
                        <button id="book_btn" name="train_btn">Add</button><br>
                        <span id="error2" style="color: red;">.</span>
                    </form>
                </div>
            </div>
</body>
</html>
<?php
    $a= new Admin();
    if(isset($_POST['journey_btn'])){
        $train=$_POST['train'];
        $st1=$_POST['st1'];
        $st2=$_POST['st2'];
        $time=$_POST['time'];
        $date=$_POST['date'];
        $r_date=$_POST['r_date'];
        if ($st1 == $st2) {
            echo "<script>
                $(document).ready(() => {
                    $('#error1').text('Source station and destination station can't be the same');
                });
            </script>";
            return;
        }
        else{ 
            if($a->add_journey((int)$train,$st1,$st2,$date,$time,$r_date)){
                echo "<script>
                $(document).ready(() => {
                    $('#error1').text('Journey added successfully');
                });
                </script>";
            }
            else{
                echo "<script>
                $(document).ready(() => {
                    $('#error1').text('Eror: database');
                });
                </script>";
            }
        }
    }
    if(isset($_POST["journey_btn_del"])){
        $id=$_POST['journey_del'];
        if($a->delete_journey($id)){
            echo "<script>
            $(document).ready(() => {
                $('#error3').text('Journey deleted successfully');
            });
            </script>";}

    }
    if(isset($_POST["train_btn"])){
        $train=$_POST["train_id"];
        $cap1=$_POST['cap_a'];
        $cap2=$_POST['cap_b'];
        if($a->add_train($train,$cap1,$cap2)){
            echo "<script>
            $(document).ready(() => {
                $('#error2').text('Train added successfully');
            });
            </script>";
        }
        else{
            echo "<script>
            $(document).ready(() => {
                $('#error2').text('Error: database error');
            });
            </script>";
        }
    }

?>