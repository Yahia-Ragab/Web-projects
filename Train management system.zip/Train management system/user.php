<?php
    include("person.php");
    class User extends person{
        function generate_qr($sou_st,$des_st,$type,$class,$date,$p_id,$j_id){
            require_once 'phpqrcode/qrlib.php';
            $data = "source station: ".$sou_st.", destination station: ". $des_st.", ticket type: ".$type. ", class: ".$class.
            ", date: ".$date.", person id: ".$p_id.", joureny id :".$j_id;
            $dir = 'img/';
            $filename = $dir . $j_id.'.png';
            $size = 10;
            $margin = 2;
            $level = 'H';
            QRcode::png($data, $filename, $level, $size, $margin);
            return $filename;
        }
        function time($srt_st,$j_id){
            $db=new Db_op();
            $j_st=$db->select1('journey',$j_id,'id');
            $j_st=$db->select1('station',$j_st[2],'id');
            $j_st_id=$j_st[0];
            $j_st=(int)$j_st[2];
            $strt_st=$db->select1('station',$srt_st,'id');
            $strt_st=(int)$strt_st[2];
            $time=$strt_st-$j_st;
            $cou=0;
            if($time>0){
            for($i=0;$i<$time;$i++){
                $t=$db->select1('station',$j_st_id+$i,'id');
                $cou+=$t[4];
            }
        }
        return $cou;
        }
        function price($srt_st,$end_st){
            $db=new Db_op();
            $strt=$db->select1('station',$srt_st,'id');
            $end=$db->select1('station',$end_st,'id');
            return ($end[2]-$strt[2])*5;
        }
        function check_set($j_id,$class){
            $db= new Db_op();
            $j_train=$db->select1('journey',$j_id,'id');
            $train_id=$j_train[1];
            $train=$db->select1('train',$train_id,'id');
            $num=$db->select_all1('ticket',$j_id,'j_id');
            $a=0;
            $b=0;
            if($num> 0){
                for($i=0;$i<count($num);$i++){
                    if($num[$i][4]=="A"){
                        $a++;
                    }
                    else{
                        $b++;
                    }
                }
                if($class=="A"){
                    if($train[1]>$a){
                        return true;
                    }
                }
                else if($class=="B"){
                    if($train[2]>$b){
                        return true;
                    }
                }
                else{
                    return false;
                }
            }
            else{return 0;}
        }
        function book_ticket($srt_st,$end_st,$type,$class,$j_id){
            $db=new Db_op();
            $u=new User();
            $time=$u->time($srt_st,$j_id);
            $price=$u->price($srt_st,$end_st);
            $date=$db->select1('journey',$j_id,'id');
            $data=$_SESSION['data'];
            echo "1";
                if($data[5]<$price){
                    // return -1;
                }
                else{
                    echo "3";
                    $qr=$u->generate_qr($srt_st,$end_st,$type,$class,$date[4],$data[0],$j_id);
                    $db->update('person',$data[5]-$price,'balance','n_id',$data[0]);
                    return $db->insert7('ticket',$srt_st,$end_st,$type,$class,$time,$j_id,$data[0],
                    'source_st','des_st','type','class','time','j_id','p_id');
                }
            
        }
        function recieve_ticket(){
            $db=new Db_op();
            $data=$_SESSION['data'];
            $resualt=$db->select_all1('ticket',$data[0],'p_id');
            return $resualt;
        }
        function register($id,$f_name,$l_name,$email,$passwrod){
            $db= new Db_op();
            return $db-> insert6('person',$id,$f_name,$l_name,$email,$passwrod,1,'n_id','f_name','l_name','email','password','role');
        }
    }
?>