<?php
    if (isset($_POST['logout'])) {
        session_start();
        session_unset();
        session_destroy();
        header("Location: login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="navigat.js"></script>
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <title></title>
    <style>
        body {
            margin: 0%;
        }
        .navbar {
            width: 100%;
            background-color: #000080;
            height: 70px;
            padding: 10px;
            margin-bottom: 10px;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar_btn {
            height: 70px;
            font-size: x-large;
            margin: 5px;
            display: inline-block;
            background: #0000B3;
            color: rgb(240, 238, 238);
            border-radius: 5px;
            border-left-color: #05052c;
            border-right-color: #05052c;
            outline: none;
            border-top: none;
            border-bottom: none;
            font-family: cursive;
        }
        .navbar_btn:active {
            background-color: green;
        }
        #logo {
            width: 85px;
            margin-top: 2px;
            margin-right: 20px;
        }
        .logout_btn {
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div>
            <button class="navbar_btn" onclick="navigate('admin_home.php')">Home</button>
            <button class="navbar_btn" onclick="navigate('admin_all_users.php')">All users</button>
            <button class="navbar_btn" onclick="navigate('admin_all_journeys.php')">All journeys</button>
            <button class="navbar_btn" onclick="navigate('admin_add_journey.php')">Train & journey</button>
            <button class="navbar_btn" onclick="navigate('admin_report.php')">Stations report</button>
            <button class="navbar_btn logout_btn"  onclick="navigate('login.php')">Logout</button>
        </div>
        <img src="img/logo.jpg" alt="LOGO" id="logo">
    </div>
</body>
</html>