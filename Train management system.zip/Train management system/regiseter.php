<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="stylesheet.css">
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#login_btn").click(function(e){
                var id = $(".n_id").val();
                var password = $(".pass").val();
                var isValid = true;
                $(".error_handel").text("");
                if(id ==='' || password===''){
                    $(".error_handel").text("*Error: Inputs must be filled");
                    isValid = false;
                }
                var numeric_id = Number(id);
                if(isNaN(numeric_id) || id.length != 14){
                    $(".error_handel").text("*Error: National ID must be a 14-digit number");
                    isValid = false;
                }
                if(isValid){
                    $("form").submit();
                }
            });
        });
    </script>
    <style>
        body{
            background-image: url("img/OIG2.StdTJA4E4w.jpg");
        }
        .login_form{
            height: 500px;
        }
    </style>
</head>
<body>
    <div class="form">
        <form action="" method="post">
            <div class="login_form">
                <h2 class="login_txt">Register</h2>
                <div class="btn_form">
                    <span class="error_handel" style="color: rgb(239, 255, 63);">.</span>
                    <input type="text" name="f_name" class="f_name" id="input_field" placeholder="Frist name">
                    <input type="text" name="l_name" class="l_name" id="input_field" placeholder="Last name">
                    <input type="number" name="n_id" class="n_id" id="input_field" placeholder="National ID">
                    <input type="text" name="email" class="email" id="input_field" placeholder="Email">
                    <input type="text" name="password" class="pass" id="input_field" placeholder="Password">
                    <button id="login_btn" name="register">Register</button>
                    <a href="login.html" style="font-size: large; color:rgb(239, 255, 63) ;">Have an account</a>
                </div>
            </div>
        </form>
</body>
</html>
<?php
    include("user.php");
    $u=new User();
    if(isset($_POST['register'])){
        $f_name=$_POST['f_name'];
        $l_name=$_POST['l_name'];
        $id=$_POST['n_id'];
        $email=$_POST['email'];
        $password=$_POST['password'];
        $valid = $u->register($id,$f_name,$l_name,$email,$password);
        if($valid==false){
            echo "<script>$('.error_handel').text('*The id is already exist');</script>";
        }
        else{
            header("Location: user_home.php");
        }
    }
?>