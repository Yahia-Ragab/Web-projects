<?php
    include("conn.php");
    include("person.php");
    class Admin extends Person{
        function check_user_trip($id){
            $db=new Db_op();
            $data=$db->select_all1("ticket",$id,"p_id");
            return $data;
        }
        function add_journey($train_id,$st1_id,$st2_id,$time,$date,$r_date){
            $db=new Db_op();
            if(empty($r_date)){
                $insert= $db->insert5("journey",$train_id,$st1_id,$st2_id,$date,$time,"train_id","start_st","end_st","date",'time');}
            else{
                $insert=$db->insert6('journey',$train_id,$st1_id,$st2_id,$date,$r_date,$time,"train_id","start_st","end_st","date",'return_date','time');
            }
            if($insert){return true;}
            else{return false;}
        }
        function delete_journey($id){
            $db=new Db_op();
            $done=$db->delete("journey",$id,"id");
            return $done;
        }
        function add_train($id,$a_cap,$b_cap){
            $db=new Db_op();
            $inser= $db->insert3("train",$id,$a_cap,$b_cap,"id","class_A_cap","class_B_cap");
            if($inser){return true;}
            else{return false;}
        }
        function see_station_report($id){
            $db=new Db_op();
            $output=$db->select_all1("st_data",$id,'st_id');
            return $output;
        }
        function recharge_balance($value,$id){
            $db=new Db_op();
            $old_price= $db->select1('person',$id,'n_id');
            $price=$old_price[5]+ $value;
            $update= $db->update("person",$price,"balance","n_id",$id);
            return $update;
        }
        function check_ticket($id){
            $db=new Db_op();
            $data=$db->select_all1("ticket",$id,"id");
            return $data;
        }
        function add_news($head,$news){
            global $conn;
            $db=new Db_op();
            $data=$_SESSION['data'];
            return $db->insert3('news',$data[0],$head,$news,'p_id','head','news');
        }
        function delete_news($id){
            global $conn;
            $db=new Db_op();
            return $db->delete('news',$id,'id');
        }
    }
?>