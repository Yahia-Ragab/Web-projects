const xhttp = new XMLHttpRequest();
xhttp.onload = function() {
    document.getElementById("content").innerHTML = this.responseText;
}
xhttp.open("GET", "navbar_admin.php", true);
xhttp.send();
function navigate(page){
    return window.location.href=page;
}
