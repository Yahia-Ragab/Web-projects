<?php
    include("user.php");
    $db = new Db_op();
    $u = new User();
    $ticket = $u->recieve_ticket();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tickets</title>
    <script src="navigate.js"></script>
    <style>
        #info {
            border-collapse: collapse;
            width: 70%;
            margin: 0 auto;
            text-align: center;
        }
        #info th, #info td {
            padding: 8px;
        }
        #info th {
            background-color: #f0f0f0;
        }
        #info td {
            border-bottom: 1px solid #ddd;
        }
        .qr-container {
            text-align: center;
            margin-bottom: 20px; 
        }
        #qr_code {
            width: 300px;
        }
    </style>
    <script>
        function printTicket($id){
            newWin=window.open();
            newWin.document.write(printData.outerHTML);
            newWin.print();
            newWin.close();
        }
    </script>
</head>
<body>
    <div id="content"></div>
    <div class="ticket">
        <?php
            for ($i = 0; $i < count($ticket); $i++) {
                $srt_name = $db->select1('station', $ticket[$i][1], 'id');
                $des_name = $db->select1('station', $ticket[$i][2], 'id');
                $date = $db->select1('journey', $ticket[$i][6], 'id');
                $ticketId = "ticket_" . $i;
                echo '<div class="qr-container">
                        <img src="img/'.$ticket[$i][6].'.png" alt="QR" id="qr_code">
                      </div>
                      <table id="info">
                        <thead>
                            <tr>
                                <th>National ID</th>
                                <th>Source station</th>
                                <th>Destination station</th>
                                <th>Travel date</th>
                                <th>Arrival time</th>
                                <th>Ticket type</th>
                                <th>Class</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>'.$ticket[$i][7].'</td>
                                <td>'.$srt_name[1].'</td>
                                <td>'.$des_name[1].'</td>
                                <td>'.$date[4].'</td>
                                <td>'.$ticket[$i][5].'</td>
                                <td>'.$ticket[$i][3].'</td>
                                <td>'.$ticket[$i][4].'</td>
                            </tr>
                        </tbody>
                      </table>';
            }
        ?>
    </div>
</body>
</html>
