<?php
    include("admin.php");
    $db=new Db_op();
    $journey=$db->select('journey');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="nav.js"></script>
    <title>Journeys</title>
    <style>
        #info {
            border-collapse: collapse;
            width: 70%;
            margin: 0 auto;
            text-align: center;
        }
        #info th, #info td {
            padding: 8px;
        }
        #info th {
            background-color: #f0f0f0;
        }
        #info td {
            border-bottom: 1px solid #ddd;
        }
        #input_field {
            margin-bottom: 10px;
            width: 300px;
            height: 20px;
            border-radius: 5px;
            font-family: cursive;
        }
        .submit_btn {
            width: 70px;
            background: white;
            border-radius: 5px;
            color: green;
            font-family: cursive;
        }
        .submit_btn:active {
            background-color: green;
            color: white;
        }
    </style>
</head>
<body>
    <div id="content"></div>
    <form action="" method="POST">
        <input type="id" name="search" id="input_field" placeholder="Journey ID">
        <button name='search_btn' class="submit_btn" >search</button>
    </form>
    <div class="ticket">
        <table id="info">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Train</th>
                    <th>Start Station</th>
                    <th>Destination Station</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Return Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($journey as $jour) {
                    $st1=$db->select1('station', $jour[2], "id");
                    $st2=$db->select1('station', $jour[3], "id");
                    echo '
                        <tr>
                            <td>'.$jour[0].'</td>
                            <td>'.$jour[1].'</td>
                            <td>'.$st1[1].'</td>
                            <td>'.$st2[1].'</td>
                            <td>'.$jour[4].'</td>
                            <td>'.$jour[6].'m</td>
                            <td>'.$jour[5].'</td>
                            <td><form method="post"><input type="hidden" name="journey_id" value="'.$jour[0].'"><button type="submit" name="delete_journey">Delete</button></form></td>
                        </tr>';
                }
                ?>
            </tbody>
        </table>
    </div>

    <?php
    if(isset($_POST['search_btn'])) {
        $search= $_POST['search'];
        if($jour=$db->select1('journey',$search,'id')){
        $st1=$db->select1('station', $jour[2], "id");
        $st2=$db->select1('station', $jour[3], "id");
        echo '
            <div class="ticket">
                <table id="info">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Train</th>
                            <th>Start Station</th>
                            <th>Destination Station</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Return Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>'.$jour[0].'</td>
                            <td>'.$jour[1].'</td>
                            <td>'.$st1[1].'</td>
                            <td>'.$st2[4].'</td>
                            <td>'.$jour[4].'</td>
                            <td>'.$jour[6].'m</td>
                            <td>'.$jour[5].'</td>
                            <td><form method="post"><input type="hidden" name="journey_id" value="'.$jour[0].'"><button type="submit" name="delete_journey">Delete</button></form></td>
                        </tr>
                    </tbody>
                </table>
            </div>';
    }}
    ?>

</body>
</html>

<?php
    $a=new Admin();
    if (isset($_POST['delete_journey'])) {
        $journey_id = $_POST['journey_id'];
        $a->delete_journey($journey_id);
    }
?>
