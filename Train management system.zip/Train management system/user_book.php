<?php
include("user.php");
$db = new Db_op();
$journeys = $db->select('journey');
$stations = $db->select('station');

$station_options = [];
foreach ($stations as $st) {
    $station_options[$st[0]] = $st[1];
}

if(isset($_POST['journey_btn'])){
    $source_station_id = $_POST['st1'];
    $destination_station_id = $_POST['st2'];
    if ($source_station_id == $destination_station_id) {
        echo "<script>
            $(document).ready(() => {
                $('#error1').text('Source station and destination station cannot be the same.');
            });
        </script>";
    } else { 
        $journey_id = $_POST['journey_id']; 
        $_POST['train_id'];
        $class=$_POST['class'];
        $type= $_POST['type'];
        $u=new User();
        $u->book_ticket($source_station_id,$destination_station_id,$type,$class,$journey_id);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add journey</title>
    <script src="navigate.js"></script>
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <style>
        .form{
            border: 2px solid black;
            border-radius: 5px;
            text-align: center;
            font-family: cursive;
            width: 500px;
            margin: 10px auto;
            
        }
        #info {
            border-collapse: collapse;
            width: 70%;
            margin: 0 auto;
            text-align: center;
        }
        #info th, #info td {
            padding: 8px;
        }
        #info th {
            background-color: #f0f0f0;
        }
        #info td {
            border-bottom: 1px solid #ddd;
        }
        #input_field {
            margin-bottom: 10px;
            width: 300px;
            height: 20px;
            border-radius: 5px;
            font-family: cursive;
        }
        .submit_btn {
            width: 70px;
            background: white;
            border-radius: 5px;
            color: green;
            font-family: cursive;
        }
        .submit_btn:active {
            background-color: green;
            color: white;
        }
        
    </style>
</head>
<body>
    <div id="content"></div>
    <?php foreach ($journeys as $journey): ?>
    <div class="form">
        <div class="book_form">
            <form action="" method="post">
                <h2>Book ticket for Journey <?php echo $journey[0]; ?></h2><br>
                <h2>train <?php echo $journey[1]; ?></h2><br>
                <input type="hidden" name="journey_id" value="<?php echo $journey[0]; ?>">
                <input type="hidden" name="train_id" value="<?php echo $journey[1]; ?>">
                <h2>date <?php echo $journey[4]; ?></h2><br>
                <h2>return date <?php echo $journey[5]; ?></h2><br>
                <h2>time <?php echo $journey[6]; ?></h2><br>
                <select name="st1" id="input_field">
                    <optgroup label="Source station"></optgroup>
                    <?php foreach ($station_options as $id => $name): ?>
                        <option id="input_field" value="<?php echo $id; ?>"><?php echo $name; ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="st2" id="input_field">
                    <optgroup label="Destination station"></optgroup>
                    <?php foreach ($station_options as $id => $name): ?>
                        <option id="input_field" value="<?php echo $id; ?>"><?php echo $name; ?></option>
                    <?php endforeach; ?>
                </select><br>
                <select name="class" id="input_field">
                        <option value="A">A</option>
                        <option value="B">B</option>
                </select>
                <select name="type" id="input_field">
                        <option value="1">one way</option>
                        <option value="2">return</option>
                    </select><br>
                <button name="journey_btn" class="submit_btn" id="book_btn">Add</button><br>
                <span id="error1" style="color: red;">.</span>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
</body>
</html>
