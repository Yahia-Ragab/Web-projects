<?php
    include("admin_st.php");
    $s = new Admin_st();
    $report = $s->see_report();
    $state = $s->display_st_state();
    $db=new Db_op();
    $journey=$db->select('journey');
    $data=$_SESSION['data'];
    $id=$data[0][11].$data[0][12].$data[0][13];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="nav.js"></script>
    <title>Station report</title>
    <style>
        h2 {
            font-family: cursive;
            text-align: center;
        }
        table {
            width: 65%;
            margin: 0 auto;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid black;
            text-align: center;
        }
        thead {
            background-color: #CCCCCC;
        }
        tbody {
            background-color: #FFFFFF;
        }
    </style>
</head>
<body>
    <div id="content"></div>
    <h2>Start journey</h2>
                <?php
                    echo'<table id="info">';
                    echo'<thead>
                        <tr>
                            <th>ID</th>
                            <th>Train</th>
                            <th>Start Station</th>
                            <th>Destination Station</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Return Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                        <tbody>';
                if(!$db->select1('active_trip',$id,'current_st')){
                foreach ($journey as $jour) {
                    $st1=$db->select1('station', $jour[2], "id");
                    $st2=$db->select1('station', $jour[3], "id");
                    echo '
                        <tr>
                            <td>'.$jour[0].'</td>
                            <td>'.$jour[1].'</td>
                            <td>'.$st1[1].'</td>
                            <td>'.$st2[1].'</td>
                            <td>'.$jour[4].'</td>
                            <td>'.$jour[6].'m</td>
                            <td>'.$jour[5].'</td>
                            <td><form method="post"><input type="hidden" name="journey_id" value="'.$jour[0].'"><button type="submit" name="start">Strart</button></form></td>
                        </tr>';
                }
                }
                echo '</tbody>
                </table>';
                ?>
    <h2>CURRENT STATE</h2>
    <?php
        if($state) {
            foreach($state as $journey) {
                echo "<h2>Station has a train <br> Journey: " . $journey['j_id'] . "<br> Total delay time: " . $journey['delay'] . " m</h2>";
                echo '<form method="post">
                        <input type="hidden" name="journey_id" value="' . $journey['j_id'] . '">
                        <button type="submit" name="leave">Leave</button>
                        <input type="number" placeholder="Delay" name="delay_i" id="input_field" value="'.$journey['delay'].'">
                        <button type="submit" name="delay">ADD delay</button>
                      </form>';
            }
        }
    ?>
    <hr>
    <h2>REPORT</h2>
    <?php
        echo '<table>
                <thead>
                    <tr>
                        <th>Station ID</th>
                        <th>Journey ID</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>';
        foreach ($report as $row) {
            echo '<tr>
                    <td>' . $row['st_id'] . '</td>
                    <td>' . $row['j_id'] . '</td>
                    <td>' . $row['date'] . '</td>
                  </tr>';
        }
        echo '</tbody></table>';
    ?>
</body>
</html>
<?php
    if(isset($_POST['leave'])) {
        $journey_id = $_POST['journey_id'];
        $s->update_st_state($journey_id);
    }
    if(isset($_POST['delay'])) {
        $delay = $_POST['delay_i'];
        $j_id = $_POST['journey_id'];
        echo $s->add_delay($j_id,$delay);
    }
    if(isset($_POST['start'])) {
        $j=$_POST['journey_id'];
        $s->start_j($j);
    }
?>
