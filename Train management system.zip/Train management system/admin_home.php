<?php
    include("admin.php");
    $db=new Db_op();
    $news=$db->select('news');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="navigat.js"></script>
    <style>
        h2{
            font-family: cursive;
            margin: 10px;
        }
        .news {
            display: flex;
            flex-direction: row;
            gap: 20px;
        }
        .card{
            border: 2px solid black;
            width: fit-content;
            padding: 10px;
            margin: 16px;
            height: fit-content;
        }
    </style>
    <title>Home</title>
</head>
<body>
    <div id="content"></div>
    <form action="" method="post" >
        <input type="text" name="header" placeholder="header" >
        <textarea type="text" name="news" placeholder="news"></textarea>
        <button name="add_news" >ADD</button>
    </form>
    <h2>announcements</h2>
    <?php
    if($news>0){
    foreach($news as $n){
        echo '<div class="news">
            <div class="card">
                <h3 style="font-family: cursive;">'.$n[2].'</h3>
                <h4 style="font-family: cursive;">'.$n[3].'</h4>
                <p style="font-family: cursive; font-size:small;">'.$n[4].'</p>
                <form method="post"><input type="hidden" name="person_id" value="'.$n[0].'"><button type="submit" name="delete">Delete</button>
            </div>';
    }}?>
    </div>
</html>
<?php
    $a=new Admin();
    if(isset($_POST['delete'])){
        $a->delete_news($n[0]);
        return;
    }
    if(isset($_POST['add_news'])){
        $a->add_news($_POST['header'],$_POST['news']);
        return;
    }
?>