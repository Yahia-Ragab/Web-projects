<?php
    include("admin.php");
    $a=new Admin();
    $db=new Db_op();
    $person=$db->select('person');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="navigat.js"></script>
    <title>Users</title>
    <style>
        #info {
            border-collapse: collapse;
            width: 70%;
            margin: 0 auto;
            text-align: center;
        }
        #info th, #info td {
            padding: 8px;
        }
        #info th {
            background-color: #f0f0f0;
        }
        #info td {
            border-bottom: 1px solid #ddd;
        }
        #input_field {
            margin-bottom: 10px;
            width: 300px;
            height: 20px;
            border-radius: 5px;
            font-family: cursive;
        }
        .submit_btn {
            width: 70px;
            background: white;
            border-radius: 5px;
            color: green;
            font-family: cursive;
        }
        .submit_btn:active {
            background-color: green;
            color: white;
        }
    </style>
</head>
<body>
    <div id="content"></div>
    <form action="" method="POST">
        <input type="id" name="search" id="input_field" placeholder="person ID">
        <button class="submit" name='search_btn'>search</button>
    </form>
    <form action="" method="POST">
        <input type="number" placeholder="Enter ID" name="id" id="input_field" >
        <input type="number" placeholder="Amount" name='price' id="input_field" >
        <button name='bal_sub' class="submit" >Submit</button>
    </form>
    <div class="ticket">
        <table id="info">
            <thead>
                <tr>
                    <th>National ID</th>
                    <th>First name</th>
                    <th>last name</th>
                    <th>email</th>
                    <th>Balance</th>
                    <th>role</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($person as $per) {
                    echo '
                        <tr>
                        <td>'.$per[0].'</td>
                        <td>'.$per[1].'</td>
                        <td>'.$per[2].'</td>
                        <td>'.$per[3].'m</td>
                        <td>'.$per[5].'</td>
                        <td>'.$per[6].'</td>
                            <td><form method="post"><input type="hidden" name="person_id" value="'.$per[0].'"><button type="submit" name="delete_person">Delete</button></form></td>
                        </tr>';
                }
                ?>
            </tbody>
        </table>
    </div>

    <?php
    if(isset($_POST['search_btn'])) {
        $search= $_POST['search'];
        if($per=$db->select1('person',$search,'n_id')){
        echo '
            <div class="ticket">
                <table id="info">
                    <thead>
                        <tr>
                        <th>National ID</th>
                        <th>First name</th>
                        <th>last name</th>
                        <th>email</th>
                        <th>Balance</th>
                        <th>role</th>
                        <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>'.$per[0].'</td>
                            <td>'.$per[1].'</td>
                            <td>'.$per[2].'</td>
                            <td>'.$per[3].'m</td>
                            <td>'.$per[5].'</td>
                            <td>'.$per[6].'</td>
                            <td><form method="post"><input type="hidden" name="person_id" value="'.$per[0].'"><button type="submit" name="delete_person">Delete</button></form></td>
                        </tr>
                    </tbody>
                </table>
            </div>';
    }}
    ?>
</body>
</html>
<?php
    if(isset($_POST['bal_sub'])){
        $id=$_POST['id'];
        $price=$_POST['price'];
        $a->recharge_balance($price,$id);
    }
?>