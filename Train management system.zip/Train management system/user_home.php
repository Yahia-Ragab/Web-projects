<?php
    include("user.php");
    $u=new User();
    $news=$u->get_news();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="navigate.js" ></script>
    <title>Train management system</title>
    <style>
        h2{
            font-family: cursive;
            margin: 10px;
        }
        .news {
            display: flex;
            flex-direction: row;
            gap: 20px;
        }
        .card{
            border: 2px solid black;
            width: fit-content;
            padding: 10px;
            margin: 16px;
            height: fit-content;
        }
    </style>
</head>

<body>
    <div id="content" ></div>
    <h2>announcements</h2>
    <div class="news">
        <?php
        if($news> 0){
            for($j=0;$j<count($news);$j++){
                echo '<div class="card">
                <h3 style="font-family: cursive;">'.$news[$j][2].'</h3>
                <h5 style="font-family: cursive;">'.$news[$j][4].'</h5>
                <p style="font-family: cursive;">'.$news[$j][3].'</p>
                </div>';    
            }
        }
        ?>
    </div>
</body>
</body>
</html>