<?php
    include("admin_st.php");
    $s = new Admin();
    $db=new Db_op();
    $report = $s->see_station_report('101');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="navigat.js"></script>
    <title>Station report</title>
    <style>
        h2 {
            font-family: cursive;
            text-align: center;
        }
        table {
            width: 65%;
            margin: 0 auto;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid black;
            text-align: center;
        }
        thead {
            background-color: #CCCCCC;
        }
        tbody {
            background-color: #FFFFFF;
        }
        #input_field {
            margin-bottom: 10px;
            width: 300px;
            height: 20px;
            border-radius: 5px;
            font-family: cursive;
        }
        .submit_btn {
            width: 70px;
            background: white;
            border-radius: 5px;
            color: green;
            font-family: cursive;
        }
        .submit_btn:active {
            background-color: green;
            color: white;
        }
    </style>
</head>
<body>
    <div id="content"></div>
    <form action="" method="POST" >
        <input type="number" name="station" id="input_field" placeholder="Inter station ID" >
        <button name="search" class="submit_btn" >Search</button>
    </form>
    <h2>REPORT</h2>
    <?php
    if ($report>0) {
        echo '<table>
                <thead>
                    <tr>
                        <th>Station ID</th>
                        <th>Journey ID</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>';
        foreach ($report as $row) {
            echo '<tr>
                    <td>' . $row[0] . '</td>
                    <td>' . $row[1] . '</td>
                    <td>' . $row[2] . '</td>
                  </tr>';
        }
        echo '</tbody></table>';}
    ?>
</body>
</html>
<?php
    if(isset($_POST['search'])){
        $s=$_POST['station'];
        $data=$db->select1('st_data',$s,'st_id');
        echo '<table>
                <thead>
                    <tr>
                        <th>Station ID</th>
                        <th>Journey ID</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>';
                echo '<tr>
                <td>' . $data[0] . '</td>
                <td>' . $data[1] . '</td>
                <td>' . $data[2] . '</td>
              </tr>';
              echo '</tbody></table>';
    }
?>